# Daniel Moyal Portfolio

Single-file, self-contained website. No build step needed.

## Deploy to GitHub Pages

1. Create a new GitHub repository and upload this folder's contents (just `index.html`).
2. In the repo, go to Settings → Pages.
3. Under "Build and deployment", set Source to "Deploy from a branch", branch `main`, folder `/ (root)`.
4. Save. Your site will be live at `https://<username>.github.io/<repo-name>/` within a minute or two.

## Deploy to Netlify or Vercel

Drag and drop this folder (or the repo) into Netlify/Vercel's dashboard, no configuration required.
